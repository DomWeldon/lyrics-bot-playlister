def main(event, context) -> None:
    """This is just a dummy function."""
    return
